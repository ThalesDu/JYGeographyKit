//
//  AppDelegate.h
//  JYGeographyKitExample
//
//  Created by djy on 2017/6/23.
//  Copyright © 2017年 Jiny. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

