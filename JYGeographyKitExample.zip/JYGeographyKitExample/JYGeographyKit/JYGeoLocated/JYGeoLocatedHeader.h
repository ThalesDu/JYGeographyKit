//
//  JYGeoLocatedHeader.h
//  JYGeographyKitExample
//
//  Created by djy on 2017/6/24.
//  Copyright © 2017年 Jiny. All rights reserved.
//

#ifndef JYGeoLocatedHeader_h
#define JYGeoLocatedHeader_h

#import "JYGeoLocatedManager.h"
#import "JYGeoLocatedReachability.h"
#import "JYGeoLocatedRequest.h"
#endif /* JYGeoLocatedHeader_h */
